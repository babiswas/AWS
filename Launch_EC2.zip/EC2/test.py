from ec2 import *
from vpc import *
from EC2_util import *
import json

def main():
   ec2_client=EC2Client()
   client=ec2_client.get_client()
   vpc=VPC(client)
   vpc_response=vpc.create_vpc()
   print("VPC_created:"+str(vpc_response))
   print("Printing json response")
   print(json.dumps(vpc_response))
   vpc_name="My_NewVPC"
   vpc_id=vpc_response['Vpc']['VpcId']
   vpc.add_name_tag(vpc_id,vpc_name)
   print("Added"+'  '+vpc_name+' '+vpc_id)
   igw_response=vpc.create_internet_gateway()
   igw_id=igw_response['InternetGateway']['InternetGatewayId']
   vpc.attach_igw_to_vpc(vpc_id,igw_id)
   public_subnet_response=vpc.create_subnet(vpc_id,'10.0.1.0/24')
   print('Subnet created for vpc'+'  '+vpc_id)
   print(public_subnet_response)
   public_route_table_response=vpc.create_public_route_table(vpc_id)
   print(json.dumps(public_route_table_response))
   rtb_id=public_route_table_response['RouteTable']['RouteTableId']
   vpc.create_igw_route_to_public_route_table(rtb_id,igw_id)
   subnet_id=public_subnet_response['Subnet']['SubnetId'] 
   vpc.add_name_tag(subnet_id,'Boto3-Public-Subnet')	
   vpc.associate_subnet_with_route_table(subnet_id,rtb_id)
   vpc.allow_auto_assign_ip_adress_for_subnet(subnet_id)
   private_subnet_response=vpc.create_subnet(vpc_id,'10.0.2.0/24')
   private_subnet_id=private_subnet_response['Subnet']['SubnetId'] 
   print("Created private subnet"+private_subnet_id+'for VPC'+vpc_id)
   #Add name tag to private subnet.
   vpc.add_name_tag(private_subnet_id,'Boto3-Private-Subnet')	
   ec2=EC2(client)
   key_pair_name='MyBoto5'
   key_pair_response=ec2.create_ec2_key_pair(key_pair_name)
   print('Creating key pair with name'+' '+key_pair_name+' '+str(key_pair_response))
   security_group='MYSG16'
   security_group_description="Public security Group Internet Access"
   public_security_group=ec2.create_security_group(security_group,security_group_description,vpc_id)
   public_security_group_id=public_security_group['GroupId']
   ec2.add_inbound_rule_to_sg(public_security_group_id)
   print("Added public access rule to Security Group"+' '+security_group)
   #Start up script
   user_data="""#!/bin/bash 
             yum update -y
             yum install httpd24 -y
             service httpd start
             chkconfig httpd on
             echo "<html><body><h1>Hello From Boto3</h1></body></html>" >/var/www/index.html """
   ami_id='ami-08d489468314a58df'
   ec2.launch_ec2_instance(ami_id,key_pair_name,1,1,public_security_group_id,subnet_id,user_data)
   print("Launching public ec2 instance with using ami"+' '+'ami-1b316af0')
   #Adding security group for private ec2 instance
   private_security_group='Boto-3-Private-SG'
   private_security_group_description='Private security group for private subnet'
   private_security_group_response=ec2.create_security_group(private_security_group,private_security_group_description,vpc_id)
   private_security_group_id=private_security_group_response['GroupId']
   #Add rule to private security group.
   ec2.add_inbound_rule_to_sg(private_security_group_id)
   ec2.launch_ec2_instance(ami_id,key_pair_name,1,1,public_security_group_id,subnet_id,user_data)
   
if __name__=="__main__":
   main()
