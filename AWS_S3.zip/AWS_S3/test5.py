import boto3

client=boto3.client('s3')
response=client.list_objects(Bucket="bapanxxxybucket")
print(response)
for x in response.get("Contents",None):
    print(x.get("Key",None))
