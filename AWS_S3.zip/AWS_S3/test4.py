import boto3

client=boto3.client('s3')

with open("test.txt",'r') as f:
   data=f.read()
   response=client.put_object(ACL='public-read-write',Body=data,Bucket="bapanxxxybucket",Key='test.txt')
   print(response)
