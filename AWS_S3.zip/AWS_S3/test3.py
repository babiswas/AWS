import boto3
from botocore.exceptions import ClientError

def create_s3_bucket(name):
   response=None
   client=boto3.client('s3')
   try:
      response=client.create_bucket(ACL='public-read-write',Bucket=name,CreateBucketConfiguration={'LocationConstraint':'us-west-2'})
   except ClientError as e:
      print(e)
   print(response)

def list_of_buckets():
   s3=boto3.client('s3')
   response=s3.list_buckets()
   print(response)
   buckets=[bucket['Name'] for bucket in response['Buckets']]
   print(buckets)


if __name__=="__main__":
   response=create_s3_bucket("bapanxxxybucket")
   list_of_buckets()
   
