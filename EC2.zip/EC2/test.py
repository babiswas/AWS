from ec2 import *
from vpc import *
import json

def main():
   ec2_client=EC2Client()
   client=ec2_client.get_client()
   vpc=VPC(client)
   vpc_response=vpc.create_vpc()
   print("VPC_created:"+str(vpc_response))
   print("Printing json response")
   print(json.dumps(vpc_response))
   vpc_name="My_NewVPC"
   vpc_id=vpc_response['Vpc']['VpcId']
   vpc.add_name_tag(vpc_id,vpc_name)
   print("Added"+'  '+vpc_name+' '+vpc_id)
   igw_response=vpc.create_internet_gateway()
   igw_id=igw_response['InternetGateway']['InternetGatewayId']
   vpc.attach_igw_to_vpc(vpc_id,igw_id)
   public_subnet_response=vpc.create_subnet(vpc_id,'10.0.1.0/24')
   print('Subnet created for vpc'+'  '+vpc_id)
   print(public_subnet_response)
   public_route_table_response=vpc.create_public_route_table(vpc_id)
   print(json.dumps(public_route_table_response))
   rtb_id=public_route_table_response['RouteTable']['RouteTableId']
   vpc.create_igw_route_to_public_route_table(rtb_id,igw_id)
   subnet_id=public_subnet_response['Subnet']['SubnetId'] 
   vpc.add_name_tag(subnet_id,'Boto3-Public-Subnet')	
   vpc.associate_subnet_with_route_table(subnet_id,rtb_id)
   vpc.allow_auto_assign_ip_adress_for_subnet(subnet_id)
   private_subnet_response=vpc.create_subnet(vpc_id,'10.0.2.0/24')
   private_subnet_id=private_subnet_response['Subnet']['SubnetId'] 
   print("Created private subnet"+private_subnet_id+'for VPC'+vpc_id)
   #Add name tag to private subnet.
   vpc.add_name_tag(private_subnet_id,'Boto3-Private-Subnet')	
   
   
   

if __name__=="__main__":
   main()
